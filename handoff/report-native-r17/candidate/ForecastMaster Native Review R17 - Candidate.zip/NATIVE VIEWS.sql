
CREATE VIEW dbo.fm_native_files AS
WITH parsed AS (
 SELECT *, REPLACE(REPLACE(UPPER(SourceFileName),'.XLSM',''),'.XLSX','') AS Stem,
  TRY_CONVERT(datetimeoffset,SUBSTRING(FileLabel,CHARINDEX(N' · Imported ',FileLabel)+12,
    CHARINDEX(N' · ',FileLabel,CHARINDEX(N' · Imported ',FileLabel)+12)
      -CHARINDEX(N' · Imported ',FileLabel)-12)) AS ImportedAt
 FROM dbo.fm_review_files
), ranked AS (
 SELECT *, CASE WHEN RIGHT(Stem,9) IN ('_PLAN_ADS','_PLAN-ADS','_PLAN ADS') OR RIGHT(Stem,8)='_PLANADS' THEN 3
   WHEN RIGHT(Stem,4)='_ADS' THEN 2
   WHEN PATINDEX('%[_]ADS[_]%',Stem)>0 AND TRY_CONVERT(bigint,
      SUBSTRING(Stem,PATINDEX('%[_]ADS[_]%',Stem)+5,50)) IS NOT NULL THEN 1 ELSE 0 END AS ADSPriority,
  CASE WHEN PATINDEX('%[_]ADS[_]%',Stem)>0 THEN COALESCE(TRY_CONVERT(bigint,
     SUBSTRING(Stem,PATINDEX('%[_]ADS[_]%',Stem)+5,50)),0) ELSE 0 END AS ADSRevision
 FROM parsed
), preference AS (
 SELECT *, DENSE_RANK() OVER(PARTITION BY Country,DemandCycle,GrowthDriver
   ORDER BY ADSPriority DESC,ADSRevision DESC,ImportedAt DESC) AS PreferenceRank
 FROM ranked
), ties AS (
 SELECT *, COUNT(*) OVER(PARTITION BY Country,DemandCycle,GrowthDriver,PreferenceRank) AS PreferenceTies
 FROM preference
)
SELECT SourceRevisionID,SourceFileName,SourceRelativePath,Country,DemandCycle,GrowthDriver,
 IMSActualsThrough,ExFactoryActualsThrough,PublicationStatus,FileLabel,
 ADSPriority,ADSRevision,PreferenceRank,PreferenceTies,
 CASE WHEN CHARINDEX('_IMS',Stem)>0 AND CHARINDEX('_',Stem,CHARINDEX('_IMS',Stem)+4)>0
 THEN SUBSTRING(Stem,CHARINDEX('_',Stem,CHARINDEX('_IMS',Stem)+4)+1,200) ELSE Stem END AS Scenario
FROM ties;
GO
CREATE VIEW dbo.fm_native_scope AS
SELECT DISTINCT f.SourceRevisionID,f.Country,f.DemandCycle,f.GrowthDriver,
 COALESCE(a.Sector,'') AS Sector,
 CONCAT(COALESCE(NULLIF(a.Sector,''),'No forecast tier'),N' – ',f.GrowthDriver) AS SectorLabel
FROM dbo.fm_native_files f
JOIN dbo.fm_review_facts a ON a.SourceRevisionID=f.SourceRevisionID;
GO
CREATE VIEW dbo.fm_native_groups AS
SELECT DISTINCT DemandCycle,'Total' AS ViewType,'' AS ScopeDriver,'' AS ScopeSector,'Selected total' AS ScopeLabel,0 AS IsSector
 FROM dbo.fm_native_scope
UNION SELECT DISTINCT DemandCycle,'Drivers',GrowthDriver,'',GrowthDriver,0 FROM dbo.fm_native_scope
UNION SELECT DISTINCT DemandCycle,'Sectors',GrowthDriver,Sector,SectorLabel,1 FROM dbo.fm_native_scope
UNION SELECT DISTINCT DemandCycle,'Both',GrowthDriver,'',GrowthDriver,0 FROM dbo.fm_native_scope
UNION SELECT DISTINCT DemandCycle,'Both',GrowthDriver,Sector,SectorLabel,1 FROM dbo.fm_native_scope;
GO
CREATE VIEW dbo.fm_native_scenario AS
SELECT 'Automatic ADS' AS Mode,'Automatic ADS' AS Scenario
UNION SELECT DISTINCT 'Selected files',Scenario FROM dbo.fm_native_files;
GO
CREATE VIEW dbo.fm_native_lines AS
SELECT g.DemandCycle,g.ViewType,g.ScopeDriver,g.ScopeSector,g.ScopeLabel,g.IsSector,
 p.Mode,p.Scenario,
 'demand' AS Chart,'none' AS Token,'' AS RowID,d.Display,
 k.LineKind,CONCAT(g.DemandCycle,CASE WHEN p.Mode='Selected files' THEN CONCAT(N' · ',p.Scenario) ELSE '' END,N' · ',g.ScopeLabel,N' · ',k.KindLabel) AS LineLabel,
 k.LineKind AS LineSort
FROM dbo.fm_native_groups g CROSS JOIN dbo.fm_native_display d CROSS JOIN dbo.fm_native_scenario p CROSS JOIN
 (VALUES(0,'Actuals'),(1,'Forecast'),(6,'6M trend'),(12,'12M trend'),(24,'24M trend')) k(LineKind,KindLabel)
UNION ALL
SELECT g.DemandCycle,g.ViewType,g.ScopeDriver,g.ScopeSector,g.ScopeLabel,g.IsSector,
 p.Mode,p.Scenario,
 'sop',s.Token,s.RowID,s.Display,k.LineKind,
 CONCAT(g.DemandCycle,CASE WHEN p.Mode='Selected files' THEN CONCAT(N' · ',p.Scenario) ELSE '' END,N' · ',g.ScopeLabel,N' · ',s.Channel,N' · ',s.SubChannel,N' · ',s.Measure,N' · ',k.KindLabel),
 s.RowRank*100+k.LineKind
FROM dbo.fm_native_groups g CROSS JOIN dbo.fm_native_scenario p JOIN dbo.fm_native_state s ON s.Kind='row'
CROSS JOIN (VALUES(0,'Actuals'),(1,'Forecast')) k(LineKind,KindLabel);
GO
